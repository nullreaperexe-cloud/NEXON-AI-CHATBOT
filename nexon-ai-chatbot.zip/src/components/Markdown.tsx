import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface MarkdownProps {
  content: string;
}

export function Markdown({ content }: MarkdownProps) {
  if (!content) return null;
  
  // Splitting content by triple backtick code blocks
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="markdown-content text-slate-200 text-sm leading-relaxed space-y-2">
      {parts.map((part, partIdx) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          // Identify language and code body
          const contentWithoutTicks = part.slice(3, -3);
          const firstNewline = contentWithoutTicks.indexOf('\n');
          let language = '';
          let code = contentWithoutTicks;

          if (firstNewline !== -1) {
            language = contentWithoutTicks.substring(0, firstNewline).trim();
            code = contentWithoutTicks.substring(firstNewline + 1);
          }

          return <CodeBlock key={partIdx} code={code} language={language} />;
        } else {
          // It's a standard text chunk
          return (
            <div
              key={partIdx}
              className="whitespace-pre-wrap break-words"
              dangerouslySetInnerHTML={{ __html: parseMarkdownText(part) }}
            />
          );
        }
      })}
    </div>
  );
}

function CodeBlock({ code, language }: { code: string; language: string; key?: React.Key }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="border border-white/10 rounded-lg overflow-hidden my-3">
      <div className="bg-slate-950/80 px-4 py-2 flex flex-row items-center justify-between border-b border-white/5 text-xs text-slate-400 font-mono">
        <span>{language.toUpperCase() || 'CODE'}</span>
        <button
          onClick={handleCopy}
          type="button"
          className="flex items-center gap-1 hover:text-cyan-400 transition-colors cursor-pointer"
        >
          {copied ? <Check className="w-3 text-emerald-400 h-3" /> : <Copy className="w-3 h-3" />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
      <pre className="p-4 bg-black/50 text-slate-100 overflow-x-auto font-mono text-xs">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function parseMarkdownText(text: string): string {
  let html = text;

  // Escape HTML characters to prevent simple injection except for tags we inject
  html = html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Bullet Lists (multi-line replacements)
  html = html.replace(/^\s*-\s+(.+)$/gm, '<li class="list-disc ml-5 mb-1 text-slate-300">$1</li>');
  html = html.replace(/^\s*\*\s+(.+)$/gm, '<li class="list-disc ml-5 mb-1 text-slate-300">$1</li>');

  // Bold Text (**)
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Inline Code (`)
  html = html.replace(/`(.*?)`/g, '<code class="bg-white/10 text-cyan-400 px-1 py-0.5 rounded text-[13px] font-mono">$1</code>');

  return html;
}
