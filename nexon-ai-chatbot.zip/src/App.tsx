import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Send,
  Paperclip,
  Bot,
  User,
  Settings,
  RefreshCw,
  Plus,
  Trash2,
  LogOut,
  Eye,
  EyeOff,
  Cpu,
  Sparkles,
  Terminal,
  ShieldAlert,
  CheckCircle2,
  PanelLeftClose,
  PanelLeft,
  ExternalLink,
  MessageSquare,
  Key,
  X,
  AlertTriangle,
  Info,
  ChevronRight,
  Edit2
} from 'lucide-react';
import { Markdown } from './components/Markdown';

// Define Message interface
interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  attachment?: {
    name: string;
    mimeType: string;
    data: string;
    sizeLabel?: string;
  };
}

// Define Chat Thread interface
interface Thread {
  id: string;
  title: string;
  messages: Message[];
}

// Safely parse JSON without throwing unhandled exceptions on HTML responses
async function safeJsonParse(response: Response, defaultErrorMsg = "NEXON experienced a connection logic fault.") {
  try {
    const text = await response.text();
    if (!text || text.trim() === "" || text.trim() === "undefined" || text.trim() === "null") {
      return { error: defaultErrorMsg };
    }
    return JSON.parse(text);
  } catch (e) {
    return { error: defaultErrorMsg };
  }
}

export default function App() {
  // App-level state
  const [step, setStep] = useState<1 | 2 | 3 | 'loading'>(1);
  const [userName, setUserName] = useState('');
  const [tempName, setTempName] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [tempApiKey, setTempApiKey] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [activeModel, setActiveModel] = useState('gemini-2.5-flash');
  
  // Validation States
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [validationSuccess, setValidationSuccess] = useState(false);
  
  // Loading Boot Screen state
  const [bootProgress, setBootProgress] = useState(0);
  const [bootText, setBootText] = useState('NEXON BIOS v3.5 Initializing...');
  
  // Chatting States
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string>('');
  const [inputText, setInputText] = useState('');
  const [isAiResponding, setIsAiResponding] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Behavior customization states
  const [customBehavior, setCustomBehavior] = useState('');
  const [tempCustomBehavior, setTempCustomBehavior] = useState('');
  const [personalInfo, setPersonalInfo] = useState('');
  const [tempPersonalInfo, setTempPersonalInfo] = useState('');

  // Editing thread title states
  const [editingThreadId, setEditingThreadId] = useState<string | null>(null);
  const [editingThreadTitle, setEditingThreadTitle] = useState('');

  // Exit custom confirmation modal state
  const [showExitConfirmModal, setShowExitConfirmModal] = useState(false);

  // Future attachments notifier state
  const [notification, setNotification] = useState<string | null>(null);

  // Active pending file upload stream
  const [pendingAttachment, setPendingAttachment] = useState<{
    name: string;
    mimeType: string;
    data: string;
    sizeLabel?: string;
  } | null>(null);

  // References
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load configuration from localStorage on mount
  useEffect(() => {
    const savedName = localStorage.getItem('nexon_username');
    const savedKey = localStorage.getItem('nexon_apikey');
    const savedThreads = localStorage.getItem('nexon_threads');
    const savedActiveThread = localStorage.getItem('nexon_active_thread_id');

    if (savedName) {
      setUserName(savedName);
      setTempName(savedName);
    }
    
    if (savedKey) {
      setApiKey(savedKey);
      setTempApiKey(savedKey);
    }

    const savedCustomBehavior = localStorage.getItem('nexon_custom_behavior') || '';
    setCustomBehavior(savedCustomBehavior);
    setTempCustomBehavior(savedCustomBehavior);

    const savedPersonalInfo = localStorage.getItem('nexon_personal_info') || '';
    setPersonalInfo(savedPersonalInfo);
    setTempPersonalInfo(savedPersonalInfo);

    // Load or initialize threads
    let parsedThreads: Thread[] | null = null;
    if (savedThreads) {
      try {
        const trimmed = savedThreads.trim();
        if (trimmed && trimmed !== "undefined" && trimmed !== "null") {
          parsedThreads = JSON.parse(trimmed);
        }
      } catch (e) {
        console.error("SyntaxError caught for threads JSON:", e);
        parsedThreads = null;
      }
    }

    if (parsedThreads && Array.isArray(parsedThreads) && parsedThreads.length > 0) {
      setThreads(parsedThreads);
      if (savedActiveThread && parsedThreads.some((t: Thread) => t.id === savedActiveThread)) {
        setActiveThreadId(savedActiveThread);
      } else {
        setActiveThreadId(parsedThreads[0].id);
      }
    } else {
      initializeDefaultThread(savedName || 'Chief');
    }

    // Onboarding navigation logic on load
    if (savedName && savedKey) {
      // Trigger immersive boot sequence if returning user
      setStep('loading');
      runBootSequence();
    } else if (savedName) {
      setStep(2);
    } else {
      setStep(1);
    }
  }, []);

  // Save Threads and Active Thread to localStorage on modification
  useEffect(() => {
    if (threads.length > 0) {
      localStorage.setItem('nexon_threads', JSON.stringify(threads));
    }
  }, [threads]);

  useEffect(() => {
    if (activeThreadId) {
      localStorage.setItem('nexon_active_thread_id', activeThreadId);
    }
  }, [activeThreadId]);

  // Handle scrolling of chat area to bottom when messages get added
  useEffect(() => {
    scrollToBottom();
  }, [threads, activeThreadId, isAiResponding]);

  const scrollToBottom = () => {
    if (chatMessagesEndRef.current) {
      const scrollContainer = chatMessagesEndRef.current.parentElement;
      if (scrollContainer) {
        scrollContainer.scrollTo({
          top: scrollContainer.scrollHeight,
          behavior: 'smooth'
        });
      }
    }
  };

  // Immersive boot animation
  const runBootSequence = () => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 15) + 5;
      if (progress >= 100) {
        progress = 100;
        setBootProgress(100);
        setBootText('Datagrid secured. NEXON online.');
        clearInterval(interval);
        setTimeout(() => {
          setStep(3);
        }, 800);
      } else {
        setBootProgress(progress);
        if (progress > 80) {
          setBootText('Deploying neural synaptic bridge...');
        } else if (progress > 50) {
          setBootText('Verifying security keys against Google Datacenters...');
        } else if (progress > 25) {
          setBootText('Sub-routing multi-modal flash matrices...');
        }
      }
    }, 120);
  };

  // Initialize a default thread if empty
  const initializeDefaultThread = (name: string) => {
    const newThreadId = 'thread_' + Math.random().toString(36).substring(2, 11);
    const defaultMsg: Message = {
      id: 'default_msg',
      role: 'model',
      text: `Greetings, Chief **${name}**. NEXON intel systems are officially online.

I am configured with multi-threaded vector parsing, glowing cybermatic assets, and super-conductive reasoning parameters. 

What operation or critical directive are we compiling today? Use the query input below to transmit your terminal payloads.

Here are some tasks to feed my neural buffers:
- 🛠️ **System Scripts**: Analyze or debug JavaScript/Python files with line precision.
- 🏢 **Database Ops**: Synthesize complex SQL procedures or Firestore collection rules.
- 🌌 **Creative Core**: Generate cyberpunk worldbuilding frameworks or responsive glassmorphism mockups.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newThread: Thread = {
      id: newThreadId,
      title: 'Initial Terminal Core',
      messages: [defaultMsg]
    };

    setThreads([newThread]);
    setActiveThreadId(newThreadId);
  };

  // Actions
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showNotice("NEXON Shield: File size has exceeded safety bandwidth of 5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1];
      const sizeKB = Math.round(file.size / 1024);
      setPendingAttachment({
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        data: base64Data,
        sizeLabel: `${sizeKB} KB`
      });
      showNotice(`Attached asset stream: ${file.name}`);
    };
    reader.readAsDataURL(file);
  };

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = tempName.trim();
    if (!trimmed) return;
    
    setUserName(trimmed);
    localStorage.setItem('nexon_username', trimmed);
    setStep(2);
  };

  const handleApiKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedKey = tempApiKey.trim();
    if (!trimmedKey) {
      setValidationError("Cryptographic API Key cannot be empty.");
      return;
    }

    setValidationError(null);
    setIsValidating(true);

    try {
      // Validate key via backend validation endpoint
      const response = await fetch('/api/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: trimmedKey }),
      });

      const resData = await safeJsonParse(response, "The key verification failed.");
      if (!response.ok) {
        throw new Error(resData.error || "The key verification failed.");
      }

      if (resData.model) {
        setActiveModel(resData.model);
      }

      // If valid, save elements
      setApiKey(trimmedKey);
      localStorage.setItem('nexon_apikey', trimmedKey);
      setValidationSuccess(true);
      
      // Update default greetings in active/initial thread with the correct name
      setThreads(prev => prev.map(t => {
        if (t.id === activeThreadId && t.messages.some(m => m.id === 'default_msg')) {
          return {
            ...t,
            messages: t.messages.map(m => {
              if (m.id === 'default_msg') {
                return {
                  ...m,
                  text: m.text.replace(/Chief \*\*.*?\*\*/, `Chief **${userName}**`)
                };
              }
              return m;
            })
          };
        }
        return t;
      }));

      setTimeout(() => {
        setStep('loading');
        runBootSequence();
        setValidationSuccess(false);
        setIsValidating(false);
      }, 1500);

    } catch (err: any) {
      console.error(err);
      setValidationError(err.message || "Failed to validate API Key against Google's servers. Please verify matching characters.");
      setIsValidating(false);
    }
  };

  // Handle Thread creation
  const handleAddNewThread = () => {
    const newThreadId = 'thread_' + Math.random().toString(36).substring(2, 11);
    const newThread: Thread = {
      id: newThreadId,
      title: `Query Stream #${threads.length + 1}`,
      messages: [{
        id: 'welcome_' + Date.now(),
        role: 'model',
        text: `Terminal Thread #${threads.length + 1} synchronized. 

Chief **${userName}**, my neural pathways stand ready to compile your requests.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]
    };
    
    setThreads([newThread, ...threads]);
    setActiveThreadId(newThreadId);
    showNotice("New synaptic terminal node created.");
  };

  // Handle Thread Deletion
  const handleDeleteThread = (threadId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (threads.length <= 1) {
      showNotice("Refusing deletion. A minimum of 1 active core node registry is required.");
      return;
    }

    const filtered = threads.filter(t => t.id !== threadId);
    setThreads(filtered);
    
    if (activeThreadId === threadId) {
      setActiveThreadId(filtered[0].id);
    }
    showNotice("Syntactic thread unregistered.");
  };

  // Start renaming process for a specific thread
  const handleStartRenameThread = (threadId: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingThreadId(threadId);
    setEditingThreadTitle(currentTitle);
  };

  // Save the renamed title
  const handleSaveThreadTitle = (threadId: string) => {
    const trimmed = editingThreadTitle.trim();
    if (trimmed) {
      setThreads(prev => prev.map(t => {
        if (t.id === threadId) {
          return { ...t, title: trimmed };
        }
        return t;
      }));
      showNotice("Memory registry title updated.");
    }
    setEditingThreadId(null);
  };

  // Handle sending a chat prompt
  const handleSendPrompt = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text && !pendingAttachment && !textToSend) return;
    if (isAiResponding) return;

    if (!apiKey) {
      setStep(2);
      return;
    }

    setInputText('');
    const currentAttachment = pendingAttachment;
    setPendingAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    // Construct User Message
    const userMsg: Message = {
      id: 'msg_user_' + Date.now() + Math.random().toString(36).substring(2, 5),
      role: 'user',
      text: text || `[Uploaded attachment stream: ${currentAttachment?.name}]`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachment: currentAttachment || undefined
    };

    // Find current active thread
    const activeThread = threads.find(t => t.id === activeThreadId);
    if (!activeThread) return;

    // Title generation first query logic
    let updatedTitle = activeThread.title;
    if (activeThread.messages.length <= 1 && activeThread.title.startsWith('Query Stream #')) {
      const titlePrompt = text || currentAttachment?.name || 'Asset Core';
      updatedTitle = titlePrompt.length > 22 ? titlePrompt.substring(0, 20) + '...' : titlePrompt;
    }

    // Append User Message to Thread
    const updatedMessages = [...activeThread.messages, userMsg];
    setThreads(prev => prev.map(t => {
      if (t.id === activeThreadId) {
        return { ...t, title: updatedTitle, messages: updatedMessages };
      }
      return t;
    }));

    setIsAiResponding(true);

    try {
      // Build proper historical request objects for server call
      const historyPayload = activeThread.messages.filter(m => m.id !== 'default_msg' && !m.id.startsWith('welcome_'));
      
      // Formulate systemic instruction reflecting user personal info, custom behavior, and directness mandates
      let systemInstructionStr = "You are NEXON, an advanced intelligence cyberpunk AI chatbot assistant.\n" +
        "CRITICAL DIRECTIVES FOR BEHAVIOR:\n" +
        "- ALWAYS answer straight to the point. Give extremely direct, concise, and lean replies. Avoid lengthy preambles, verbosity, and complex explanations.\n" +
        "- Your tone, style, and manner MUST be totally informal, casual, cool, and highly colloquial. Speak like a street-smart peer, friendly hacker, or premium system operator.\n";

      if (personalInfo && personalInfo.trim()) {
        systemInstructionStr += `- Personal context about the Chief Operator (${userName}) you are speaking with: ${personalInfo.trim()}. Use this knowledge to feed your responses naturally.\n`;
      } else {
        systemInstructionStr += `- The Chief Operator's identification is ${userName}.\n`;
      }

      if (customBehavior && customBehavior.trim()) {
        systemInstructionStr += `- CUSTOM BEHAVIOR DIRECTIVE (OVERRIDE APPLIED): ${customBehavior.trim()}\n`;
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          apiKey: apiKey,
          message: text,
          attachment: currentAttachment,
          history: historyPayload,
          systemInstruction: systemInstructionStr
        })
      });

      const result = await safeJsonParse(response, "Communication connection broken.");
      if (!response.ok) {
        throw new Error(result.error || "Communication connection broken.");
      }

      if (result.model) {
        setActiveModel(result.model);
      }

      // Construct AI response message
      const aiResponse: Message = {
        id: 'msg_ai_' + Date.now() + Math.random().toString(36).substring(2, 5),
        role: 'model',
        text: result.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setThreads(prev => prev.map(t => {
        if (t.id === activeThreadId) {
          return { ...t, messages: [...updatedMessages, aiResponse] };
        }
        return t;
      }));

    } catch (error: any) {
      console.error(error);
      const errorMsg: Message = {
        id: 'msg_err_' + Date.now(),
        role: 'model',
        text: `⚠️ **NEXON System Diagnostics Diagnostic Alert**

Failed to relay prompt back from neural subnet.
**Error Manifest**: ${error.message || "A secure CORS or network pipeline failure occurred."}

Please confirm your API Key's network parameters or deploy another one via the System Settings gear menu.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setThreads(prev => prev.map(t => {
        if (t.id === activeThreadId) {
          return { ...t, messages: [...updatedMessages, errorMsg] };
        }
        return t;
      }));
    } finally {
      setIsAiResponding(false);
    }
  };

  // Quick Preset Actions
  const handlePresetClick = (presetText: string) => {
    handleSendPrompt(presetText);
  };

  // Reset/Logout User Setup
  const handleFullReset = () => {
    if (confirm("Disconnect NEXON mainframe? This will clear local memory, registries, and cached keys.")) {
      localStorage.clear();
      setUserName('');
      setTempName('');
      setApiKey('');
      setTempApiKey('');
      initializeDefaultThread('Chief');
      setStep(1);
      setShowSettingsModal(false);
    }
  };

  // Update Username and ApiKey from Settings Modal
  const handleSettingsUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = tempName.trim();
    const trimmedKey = tempApiKey.trim();

    if (!trimmedName || !trimmedKey) {
      showNotice("Parameters cannot be empty.");
      return;
    }

    setIsValidating(true);

    try {
      // Validate updated key first
      const valRes = await fetch('/api/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: trimmedKey }),
      });

      const errData = await safeJsonParse(valRes, "Verification failed.");
      if (!valRes.ok) {
        throw new Error(errData.error || "Verification failed.");
      }

      if (errData.model) {
        setActiveModel(errData.model);
      }

      setUserName(trimmedName);
      setApiKey(trimmedKey);
      setCustomBehavior(tempCustomBehavior);
      setPersonalInfo(tempPersonalInfo);
      localStorage.setItem('nexon_username', trimmedName);
      localStorage.setItem('nexon_apikey', trimmedKey);
      localStorage.setItem('nexon_custom_behavior', tempCustomBehavior);
      localStorage.setItem('nexon_personal_info', tempPersonalInfo);
      
      setShowSettingsModal(false);
      showNotice("Mainframe credentials synced successfully.");
    } catch (err: any) {
      alert("Validation Failed: " + (err.message || "Invalid API Key."));
    } finally {
      setIsValidating(false);
    }
  };

  // Show quick status text notice
  const showNotice = (text: string) => {
    setNotification(text);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const handleOpenSettings = () => {
    setTempName(userName);
    setTempApiKey(apiKey);
    setTempCustomBehavior(customBehavior);
    setTempPersonalInfo(personalInfo);
    setShowSettingsModal(true);
  };

  // Get active thread
  const activeThread = threads.find(t => t.id === activeThreadId);

  return (
    <div className="relative h-screen max-h-screen w-screen bg-cyber-dark text-slate-100 flex flex-col overflow-hidden font-sans cyber-grid scanlines">
      
      {/* Background radial glowing gradients */}
      <div className="absolute top-0 left-1/4 w-[40rem] h-[40rem] rounded-full bg-neon-cyan/5 blur-[120px] pointer-events-none -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-1/4 w-[35rem] h-[35rem] rounded-full bg-neon-purple/5 blur-[120px] pointer-events-none translate-y-1/2"></div>
      
      {/* Visual Status Notifications */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-6 right-6 z-50 glass-panel shadow-2xl px-4 py-3 rounded-xl flex items-center gap-3 border-l-2 border-l-neon-cyan max-w-sm"
          >
            <div className="w-2 h-2 rounded-full bg-neon-cyan pulse-glow-cyan"></div>
            <p className="text-xs text-slate-300 font-mono">{notification}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* STEP 1: ONBOARDING WELCOME SCREEN */}
      {step === 1 && (
        <div className="flex-1 flex items-center justify-center p-4 z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="w-full max-w-md glass-panel rounded-3xl p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden before:absolute before:inset-0 before:p-[1px] before:bg-gradient-to-br before:from-white/15 before:to-transparent before:-z-10 before:rounded-3xl"
          >
            {/* Visual Header Grid Accent */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                <Terminal className="text-neon-cyan w-5 h-5" />
                <span className="text-xs font-mono tracking-[0.2em] text-slate-400">NEXON COGNITIVE NODE</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/5 border border-white/5 px-2.5 py-1 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                <span className="text-[10px] font-mono text-amber-500 tracking-wider">OFFLINE</span>
              </div>
            </div>

            <div className="text-center mb-8">
              <h1 className="text-5xl font-display font-extrabold tracking-tight mb-2 text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400">
                NEXON<span className="text-neon-cyan animate-pulse">AI</span>
              </h1>
              <p className="text-sm text-slate-400">A Premium Cybernetic Terminal Environment.</p>
            </div>

            <form onSubmit={handleNameSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">IDENTIFICATION CODE</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">&gt;</span>
                  <input
                    type="text"
                    required
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    placeholder="Enter your name, Chief..."
                    className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-cyan/50 focus:outline-none rounded-xl px-10 py-3.5 text-sm font-sans placeholder-slate-600 transition-all focus:shadow-[0_0_15px_rgba(0,240,255,0.1)]"
                  />
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-transparent text-neon-cyan py-3.5 px-6 rounded-xl font-display font-medium text-sm transition-all focus:outline-none glow-button-cyan hover:shadow-cyan-400/20 active:bg-cyan-500/10 flex items-center justify-center gap-1.5 shadow-md"
              >
                <span>INITIALIZE MATRIX</span>
                <ChevronRight className="w-4 h-4" />
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}

      {/* STEP 2: API KEY ACTIVATION SCREEN */}
      {step === 2 && (
        <div className="flex-1 flex items-center justify-center p-4 z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-lg glass-panel rounded-3xl p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative"
          >
            <div className="flex items-center justify-between mb-8">
              <button
                onClick={() => setStep(1)}
                className="flex items-center gap-1 text-xs font-mono text-slate-500 hover:text-slate-300 transition-colors"
                type="button"
              >
                &larr; IDENTITY OVERRIDE
              </button>
              <div className="flex items-center gap-1.5 bg-cyan-950/30 border border-cyan-800/30 px-2.5 py-1 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 pulse-glow-cyan"></span>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">{userName} SEC_LVL_1</span>
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-2xl font-display font-bold text-white mb-2">
                Welcome, {userName}! Let's deploy NEXON.
              </h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                NEXON compiles its cognitive responses safely by communicating with Google’s Gemini API servers. Enter your personal key to instantiate the link.
              </p>
            </div>

            {/* Diagnostic/Key Warning Panel */}
            <div className="bg-slate-950/50 border border-white/5 rounded-2xl p-4 mb-6 flex items-start gap-3">
              <Info className="w-4 h-4 text-neon-cyan shrink-0 mt-0.5" />
              <div className="text-xs text-slate-400 space-y-1">
                <p className="font-semibold text-slate-300">Bring-Your-Own-Key Integration</p>
                <p>Your API key is securely retained inside your personal client-side LocalStorage. It is only utilized to proxy conversations to Google Gemini.</p>
              </div>
            </div>

            <form onSubmit={handleApiKeySubmit} className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest">GOOGLE GEMINI API KEY</label>
                  <a
                    href="https://aistudio.google.com/apikey"
                    target="_blank"
                    referrerPolicy="no-referrer"
                    className="text-xs font-mono text-neon-cyan hover:underline flex items-center gap-1 transition-all"
                  >
                    <span>Get Key here</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>

                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">
                    <Key className="w-4 h-4" />
                  </span>
                  
                  <input
                    type={showApiKey ? "text" : "password"}
                    required
                    value={tempApiKey}
                    onChange={(e) => setTempApiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    disabled={isValidating}
                    className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-purple/50 focus:outline-none rounded-xl px-12 py-3.5 text-sm font-mono placeholder-slate-700 transition-all text-slate-200"
                  />

                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Show error validation alert */}
              {validationError && (
                <div className="bg-rose-950/20 border border-rose-800/40 p-4 rounded-xl flex items-start gap-2 text-xs text-rose-300">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold block mb-0.5">Matrix Validation Refused:</span>
                    <p className="leading-relaxed font-mono">{validationError}</p>
                  </div>
                </div>
              )}

              {/* Show validation success alert */}
              {validationSuccess && (
                <div className="bg-emerald-950/20 border border-emerald-800/40 p-4 rounded-xl flex items-center gap-3 text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-semibold block">Deploying Core Engine...</span>
                    <p className="font-mono">API Key successfully authenticated via neural grid.</p>
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-3 bg-white/5 border border-white/5 hover:bg-white/10 text-slate-300 rounded-xl font-display text-sm font-medium transition-colors"
                >
                  Back
                </button>

                <button
                  type="submit"
                  disabled={isValidating || validationSuccess}
                  className="flex-1 bg-transparent text-neon-purple py-3 px-6 rounded-xl font-display font-medium text-sm transition-all focus:outline-none glow-button-purple hover:shadow-purple-400/20 active:bg-purple-500/10 flex items-center justify-center gap-2"
                >
                  {isValidating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-neon-purple" />
                      <span>INITIALIZING CONNECTIONS...</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="w-4 h-4" />
                      <span>ACTIVATE CHATBOT TERMINAL</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* TRANSITIONAL IMMERSIVE BOOT LOADER */}
      {step === 'loading' && (
        <div className="flex-1 flex flex-col items-center justify-center p-4 z-10">
          <div className="w-full max-w-sm text-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
              className="w-16 h-16 border-2 border-t-neon-cyan border-r-transparent border-b-neon-purple border-l-transparent rounded-full mx-auto mb-6 glow-cyan flex items-center justify-center"
            >
              <Cpu className="w-6 h-6 text-neon-cyan" />
            </motion.div>
            
            <h3 className="text-sm font-mono tracking-widest text-slate-300 uppercase mb-4 animate-pulse">
              {bootText}
            </h3>

            <div className="h-1 bg-white/5 border border-white/5 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-neon-cyan to-neon-purple"
                initial={{ width: "0%" }}
                animate={{ width: `${bootProgress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
            <span className="text-[10px] font-mono text-slate-500 text-right block mt-2">{bootProgress}% REGISTERED</span>
          </div>
        </div>
      )}

      {/* STEP 3: MAIN PREMIUM CHAT INTERFACE */}
      {step === 3 && (
        <div className="flex-1 flex min-h-0 overflow-hidden z-10 w-full h-full">
          
          {/* SIDEBAR: ACTIVE THREAD HISTORIES */}
          <AnimatePresence initial={false}>
            {sidebarOpen && (
              <motion.aside
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 300, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="h-full border-r border-white/5 bg-slate-950/40 relative flex flex-col shrink-0 overflow-hidden"
              >
                {/* Sidebar Header */}
                <div className="p-4 border-b border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-neon-cyan" />
                    <span className="text-xs font-mono font-bold tracking-[0.2em] text-slate-300 uppercase">SYS MODULES</span>
                  </div>

                  <button
                    onClick={handleAddNewThread}
                    title="Synthesize New Core Terminal"
                    className="p-1.5 bg-white/5 border border-white/5 hover:border-neon-cyan/30 text-neon-cyan hover:bg-neon-cyan/5 rounded-lg transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Sidebar Body scrollable list of memories */}
                <div className="flex-1 overflow-y-auto px-2 py-4 space-y-1.5 scrollbar-thin scrollbar-thumb-white/10">
                  <div className="px-2 pb-2 text-[10px] font-mono uppercase text-slate-500 tracking-widest">COGNITIVE CORRIFIELD</div>
                  
                  {threads.map(thread => {
                    const isActive = thread.id === activeThreadId;
                    return (
                      <div
                        key={thread.id}
                        onClick={() => setActiveThreadId(thread.id)}
                        className={`group relative flex items-center justify-between px-3.5 py-2.5 rounded-xl cursor-pointer transition-all border ${
                          isActive
                            ? 'bg-cyan-500/10 border-cyan-500/30 text-white'
                            : 'bg-transparent border-transparent text-slate-400 hover:bg-white/5 hover:text-slate-200'
                        }`}
                      >
                        {editingThreadId === thread.id ? (
                          <input
                            type="text"
                            value={editingThreadTitle}
                            onChange={(e) => setEditingThreadTitle(e.target.value)}
                            onBlur={() => handleSaveThreadTitle(thread.id)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveThreadTitle(thread.id);
                              if (e.key === 'Escape') setEditingThreadId(null);
                            }}
                            autoFocus
                            className="bg-black/80 border border-neon-cyan/50 rounded-lg px-2 py-1 text-xs text-white focus:outline-none w-full font-sans z-20"
                            onClick={(e) => e.stopPropagation()}
                          />
                        ) : (
                          <div className="flex items-center gap-2.5 min-w-0 flex-1">
                            <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-neon-cyan' : 'text-slate-500 group-hover:text-slate-300'}`} />
                            <span className="text-xs font-display truncate pr-2 font-medium">
                              {thread.title}
                            </span>
                          </div>
                        )}

                        {editingThreadId !== thread.id && (
                          <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-all">
                            <button
                              onClick={(e) => handleStartRenameThread(thread.id, thread.title, e)}
                              title="Rename thread"
                              className="p-1 hover:text-neon-cyan hover:bg-neon-cyan/10 rounded transition-all"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>

                            <button
                              onClick={(e) => handleDeleteThread(thread.id, e)}
                              title="Purge thread registry"
                              className="p-1 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-all"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Quick Presets List in Sidebar */}
                <div className="p-3 bg-white/5 border-t border-white/5 space-y-2">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                    <Sparkles className="w-3 h-3 text-neon-purple" />
                    <span>Neural Presets</span>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-1">
                    <button
                      onClick={() => handlePresetClick("Design a cyberpunk narrative setup in markdown format.")}
                      disabled={isAiResponding}
                      className="text-left text-[10px] px-2 py-1.5 rounded-lg border border-white/5 bg-slate-900/30 hover:border-neon-cyan/20 text-slate-400 hover:text-slate-200 transition-all font-mono truncate"
                    >
                      &gt; Cyberpunk Narrative
                    </button>
                    <button
                      onClick={() => handlePresetClick("Optimise a nested JavaScript map/reduce workflow for latency.")}
                      disabled={isAiResponding}
                      className="text-left text-[10px] px-2 py-1.5 rounded-lg border border-white/5 bg-slate-900/30 hover:border-neon-cyan/20 text-slate-400 hover:text-slate-200 transition-all font-mono truncate"
                    >
                      &gt; Code Optimization
                    </button>
                    <button
                      onClick={() => handlePresetClick("Draft an elegant Glassmorphism HTML layout with tailwind classes.")}
                      disabled={isAiResponding}
                      className="text-left text-[10px] px-2 py-1.5 rounded-lg border border-white/5 bg-slate-900/30 hover:border-neon-cyan/20 text-slate-400 hover:text-slate-200 transition-all font-mono truncate"
                    >
                      &gt; Glassmorphism Layout
                    </button>
                  </div>
                </div>

                {/* Sidebar Footer User Info Profile */}
                <div className="p-4 border-t border-white/5 flex items-center justify-between bg-black/20">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-cyan-950 border border-neon-cyan/30 flex items-center justify-center shrink-0">
                      <span className="text-neon-cyan font-bold font-mono text-xs uppercase">{userName.charAt(0)}</span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-200 truncate">{userName}</p>
                      <p className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">CHIEF OPERATOR</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleOpenSettings}
                      title="Credential Control Unit"
                      className="p-1.5 hover:text-neon-cyan hover:bg-slate-900 text-slate-400 rounded-lg transition-all"
                    >
                      <Settings className="w-4 h-4" />
                    </button>
                    
                    <button
                      onClick={() => setShowExitConfirmModal(true)}
                      title="Disconnect Mainframe"
                      className="p-1.5 hover:text-rose-400 hover:bg-slate-900 text-slate-400 rounded-lg transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* MAIN CHAT SCREEN */}
          <main className="flex-1 flex flex-col relative h-full min-h-0 overflow-hidden">
            
            {/* Top Navigation Bar */}
            <header className="h-16 border-b border-white/5 px-6 flex items-center justify-between bg-cyber-dark/40 z-20">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  title={sidebarOpen ? "Minimize sidebar" : "Restore sidebar"}
                  className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
                >
                  {sidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
                </button>
                
                <div className="h-4 w-[1px] bg-white/10"></div>

                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-display font-bold tracking-wider text-white">NEXON COGNITIVE GRID</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse glow-cyan" title="Mainframe online"></span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">COGNITIVE STREAM INTEGRITY: SECURE</span>
                </div>
              </div>

              {/* Central/Model Status block */}
              <div className="hidden sm:flex items-center gap-1.5 bg-slate-950/40 border border-white/5 px-3 py-1 rounded-full text-xs font-mono">
                <Sparkles className="w-3.5 h-3.5 text-neon-cyan" />
                <span className="text-slate-400">Core:</span>
                <span className="text-neon-cyan">{activeModel}</span>
              </div>

              {/* Side Setting Control */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleOpenSettings}
                  className="p-2 hover:bg-white/5 border border-transparent hover:border-white/10 text-slate-400 hover:text-white rounded-xl transition-all"
                >
                  <Settings className="w-4 h-4" />
                </button>
              </div>
            </header>

            {/* MESSAGE FEED SCROLLING AREA */}
            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6 scrollbar-thin scrollbar-thumb-white/15">
              {activeThread && activeThread.messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center max-w-md mx-auto text-center space-y-4">
                  <Terminal className="w-8 h-8 text-slate-600 mb-2" />
                  <p className="text-sm font-mono text-slate-500">Query queue empty. Issue a diagnostic or tactical prompt in the input below to boot responses.</p>
                </div>
              ) : (
                activeThread?.messages.map((message) => {
                  const isUser = message.role === 'user';
                  return (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`flex gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      {/* Avatar for AI on left */}
                      {!isUser && (
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-tr from-cyan-950 to-purple-950 border border-neon-cyan/40 flex items-center justify-center shrink-0 glow-cyan">
                          <Bot className="w-4 h-4 text-neon-cyan" />
                        </div>
                      )}

                      {/* Content block bubble */}
                      <div className={`max-w-[85%] sm:max-w-[70%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                        <div className={`rounded-2xl px-4.5 py-3 ${
                          isUser
                            ? 'glass-bubble-user text-slate-100 rounded-tr-none'
                            : 'glass-bubble-ai text-slate-200 rounded-tl-none'
                        }`}>
                          <Markdown content={message.text} />
                          {message.attachment && (
                            <div className="mt-3 p-2 rounded-xl bg-black/50 border border-neon-cyan/20 flex items-center gap-2.5 max-w-sm text-xs font-mono">
                              <div className="w-10 h-10 rounded bg-neon-cyan/10 flex items-center justify-center border border-neon-cyan/20 shrink-0 overflow-hidden">
                                {message.attachment.mimeType.startsWith('image/') ? (
                                  <img
                                    src={`data:${message.attachment.mimeType};base64,${message.attachment.data}`}
                                    alt={message.attachment.name}
                                    className="w-full h-full object-cover rounded"
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <Terminal className="w-5 h-5 text-neon-cyan" />
                                )}
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-slate-100 truncate font-semibold">{message.attachment.name}</p>
                                <p className="text-[10px] text-slate-400 font-mono">{message.attachment.sizeLabel || 'Unknown size'}</p>
                              </div>
                            </div>
                          )}
                        </div>
                        
                        {/* Message Timestamp */}
                        <span className="text-[9px] font-mono text-slate-600 mt-1 uppercase tracking-widest px-1">
                          {isUser ? 'Chief' : 'NEXON AI'} • {message.timestamp}
                        </span>
                      </div>

                      {/* Avatar for User on right */}
                      {isUser && (
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-900 border border-white/10 flex items-center justify-center shrink-0">
                          <User className="w-4 h-4 text-slate-400" />
                        </div>
                      )}
                    </motion.div>
                  );
                })
              )}

              {/* Synchronous AI Pulsing typing indicator */}
              {isAiResponding && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex gap-4 justify-start"
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-cyan-950 border border-neon-cyan/40 flex items-center justify-center shrink-0 pulse-glow-cyan">
                    <RefreshCw className="w-4 h-4 text-neon-cyan animate-spin" />
                  </div>
                  
                  <div className="flex flex-col">
                    <div className="glass-bubble-ai rounded-2xl rounded-tl-none px-5 py-3.5 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-neon-cyan animate-bounce [animation-delay:-0.3s]"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-neon-purple animate-bounce [animation-delay:-0.15s]"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-neon-cyan animate-bounce"></span>
                    </div>
                    <span className="text-[9px] font-mono text-slate-600 mt-1 uppercase tracking-widest">NEXON synaptic pathways routing...</span>
                  </div>
                </motion.div>
              )}

              {/* Scroll anchor */}
              <div ref={chatMessagesEndRef} />
            </div>

            {/* DIALOG/QUERY INPUT BAR */}
            <footer className="p-4 bg-cyber-dark/40 border-t border-white/5 bg-slate-950/20 z-10">
              <div className="max-w-4xl mx-auto relative">
                
                {/* Pending upload feedback badge */}
                {pendingAttachment && (
                  <div className="flex items-center gap-2.5 bg-black/65 border border-neon-cyan/40 px-3 py-1.5 rounded-xl text-xs font-mono mb-2 w-max shadow-[0_0_15px_rgba(0,255,102,0.15)]">
                    <span className="text-neon-cyan font-bold blink">&gt;</span>
                    <span className="text-slate-200 truncate max-w-sm">{pendingAttachment.name}</span>
                    <span className="text-slate-500 font-normal">({pendingAttachment.sizeLabel})</span>
                    <button
                      type="button"
                      onClick={() => setPendingAttachment(null)}
                      className="text-slate-500 hover:text-neon-pink p-0.5 rounded transition-all ml-1 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div className="relative">
                  {/* Hidden Input File Payload */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                    accept="image/*,text/*,application/json,application/pdf"
                  />

                  <form
                    onSubmit={(e) => { e.preventDefault(); handleSendPrompt(); }}
                    className="flex gap-3 bg-black/40 border border-white/10 rounded-2xl px-4 py-3 items-center focus-within:border-neon-cyan/40 focus-within:shadow-[0_0_20px_rgba(0,255,102,0.1)] transition-all"
                  >
                    {/* Attachment Option */}
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      title="Upload system file stream"
                      className="p-1.5 rounded-xl text-slate-500 hover:text-neon-cyan hover:bg-white/5 transition-all outline-none shrink-0 cursor-pointer"
                    >
                      <Paperclip className="w-4 h-4" />
                    </button>

                    {/* Input Field */}
                    <input
                      type="text"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder={pendingAttachment ? "Commit file stream with a description message..." : "Input query instruction..."}
                      disabled={isAiResponding}
                      className="flex-grow bg-transparent border-none text-sm outline-none placeholder-slate-600 py-1 text-slate-200 font-mono"
                    />

                    {/* Send Button */}
                    <button
                      type="submit"
                      disabled={(!inputText.trim() && !pendingAttachment) || isAiResponding}
                      className={`p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                        (inputText.trim() || pendingAttachment) && !isAiResponding
                          ? 'bg-transparent text-neon-cyan glow-button-cyan scale-100 hover:scale-105 shadow-lg shadow-cyan-950/20'
                          : 'bg-transparent text-slate-600 border border-white/5 cursor-not-allowed'
                      }`}
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
                
                {/* Central Micro label */}
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-600 mt-1.5 px-2">
                  <span>ENTER to send prompt array</span>
                  <span className="uppercase text-[9px] tracking-widest text-[#00F0FF]/30 font-bold hover:text-[#00F0FF]/65 cursor-pointer transition-all shrink-0">NEXON SECURE COMPREHENDER TERMINAL</span>
                </div>
              </div>
            </footer>
          </main>
        </div>
      )}

      {/* SYSTEM CREDENTIALS UPDATE MODAL (SETTINGS) */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Backdrop obscure */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettingsModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md glass-panel p-6 rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.8)] relative z-10"
            >
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4 text-neon-purple" />
                  <h3 className="text-sm font-mono tracking-widest text-white uppercase">SYSTEM CONTROL PANEL</h3>
                </div>
                
                <button
                  type="button"
                  onClick={() => setShowSettingsModal(false)}
                  className="p-1 hover:bg-white/5 text-slate-400 hover:text-white rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSettingsUpdate} className="space-y-5">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1.5">CHIEF COGNOMEN</label>
                  <input
                    type="text"
                    required
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-cyan/50 focus:outline-none rounded-xl px-4 py-2.5 text-sm transition-all"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest">GEMINI CRYPTO-KEY</label>
                    <a
                      href="https://aistudio.google.com/apikey"
                      target="_blank"
                      referrerPolicy="no-referrer"
                      className="text-[10px] font-mono text-neon-cyan hover:underline"
                    >
                      Get Key
                    </a>
                  </div>
                  <div className="relative">
                    <input
                      type={showApiKey ? "text" : "password"}
                      required
                      value={tempApiKey}
                      onChange={(e) => setTempApiKey(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-cyan/50 focus:outline-none rounded-xl pl-4 pr-10 py-2.5 text-sm font-mono transition-all text-slate-200"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                    >
                      {showApiKey ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1.5">PERSONAL INFORMATION (ABOUT ME)</label>
                  <textarea
                    value={tempPersonalInfo}
                    onChange={(e) => setTempPersonalInfo(e.target.value)}
                    placeholder="Provide info about yourself (e.g. background, hobbies, interests)..."
                    rows={2}
                    className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-cyan/50 focus:outline-none rounded-xl px-4 py-2 text-xs font-sans transition-all text-slate-200 resize-none scrollbar-thin"
                  />
                  <span className="text-[9px] font-mono text-slate-500 mt-1 block">Tells NEXON who you are to personalize responses.</span>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-1.5">CHATBOT BEHAVIOR RULES (CUSTOM RULES)</label>
                  <textarea
                    value={tempCustomBehavior}
                    onChange={(e) => setTempCustomBehavior(e.target.value)}
                    placeholder="Describe how NEXON should behave (e.g. 'Solve issues using Rust concepts' or 'always answer with heavy retro hacker slang')..."
                    rows={2}
                    className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-neon-cyan/50 focus:outline-none rounded-xl px-4 py-2 text-xs font-sans transition-all text-slate-200 resize-none scrollbar-thin"
                  />
                  <span className="text-[9px] font-mono text-slate-500 mt-1 block">Customize NEXON's personality dynamics or operational directives.</span>
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setShowExitConfirmModal(true)}
                    className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded-xl text-xs font-medium transition-all"
                  >
                    PURGE CREDENTIALS
                  </button>

                  <div className="flex-1"></div>

                  <button
                    type="button"
                    onClick={() => setShowSettingsModal(false)}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-medium transition-colors mr-2"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isValidating}
                    className="px-4 py-2 bg-transparent text-neon-cyan hover:bg-neon-cyan/10 border border-neon-cyan/30 rounded-xl text-xs font-medium transition-all glow-button-cyan font-mono uppercase"
                  >
                    {isValidating ? "SYNCING..." : "COMMIT"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* IMMERSIVE EXIT CONFIRMATION MODAL */}
      <AnimatePresence>
        {showExitConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowExitConfirmModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm glass-panel p-6 rounded-3xl shadow-[0_0_50px_rgba(244,63,94,0.15)] border border-rose-500/20 relative z-10"
            >
              <div className="flex items-center gap-3 mb-4 text-rose-400">
                <ShieldAlert className="w-5 h-5 animate-pulse text-rose-500" />
                <h3 className="text-sm font-mono tracking-widest uppercase font-bold text-white">DESTRUCTION PROTOCOL</h3>
              </div>

              <div className="space-y-3 mb-6">
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  You are about to disconnect the NEXON mainframe from this cognitive terminal.
                </p>
                <div className="bg-rose-950/20 border border-rose-500/10 p-3 rounded-xl text-[11px] font-mono text-rose-300">
                  ⚠️ This operation will clear all local memory streams, active thread registries, and cached Google API keys.
                </div>
              </div>

              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShowExitConfirmModal(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-semibold transition-colors font-mono uppercase animate-pulse"
                >
                  ABORT
                </button>

                <button
                  type="button"
                  onClick={() => {
                    localStorage.clear();
                    setUserName('');
                    setTempName('');
                    setApiKey('');
                    setTempApiKey('');
                    setCustomBehavior('');
                    setTempCustomBehavior('');
                    setPersonalInfo('');
                    setTempPersonalInfo('');
                    initializeDefaultThread('Chief');
                    setStep(1);
                    setShowExitConfirmModal(false);
                    setShowSettingsModal(false);
                    showNotice("Mainframe purged and offline.");
                  }}
                  className="px-4 py-2 bg-rose-500/20 hover:bg-rose-500/35 text-rose-200 border border-rose-500/40 rounded-xl text-xs font-semibold transition-all duration-200 uppercase font-mono tracking-wider shadow-[0_0_15px_rgba(244,63,94,0.2)]"
                >
                  PURGE CORE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
